# import streamlit as st
# import pandas as pd
# import numpy as np
# import matplotlib.pyplot as plt
# import seaborn as sns
# from PIL import Image
# import pydeck as pdk

# # Set page config
# st.set_page_config(
#     page_title="Earthquake Prediction System",
#     page_icon="🌍",
#     layout="wide"
# )

# # Custom CSS for styling
# st.markdown("""
# <style>
# .alert-card {
#     # background-color: white;
#     color: #212529; 
#     padding: 1.5rem;
#     margin-bottom: 1rem;
#     border-radius: 0.5rem;
#     box-shadow: 0 4px 8px rgba(0,0,0,0.1);
#     border-left: 5px solid #d9534f;
# }
# .location-header {
#     color: #d9534f;
#     margin-bottom: 0.5rem;
# }
# .map-container {
#     border-radius: 0.5rem;
#     overflow: hidden;
# }
# </style>
# """, unsafe_allow_html=True)

# # Load predictions
# try:
#     predictions = pd.read_csv('earthquake_predictions_2025-2030.csv')
# except:
#     # If no CSV exists, create sample data with correct column names
#     data = {
#         'year': [2025, 2026, 2027, 2028, 2029, 2030] * 3,
#         'latitude': [36.77, 34.05, 38.58, 37.77, 35.47, 32.72] * 3,
#         'longitude': [-119.42, -118.24, -121.49, -122.42, -120.67, -117.16] * 3,
#         'depth': [10.5, 15.2, 8.7, 12.3, 9.8, 11.5] * 3,
#         'predicted_magnitude': [5.2, 6.1, 5.7, 7.2, 6.5, 5.9] * 3
#     }
#     predictions = pd.DataFrame(data)

# # Add country names based on coordinates (simplified for demo)
# def get_country(lat, lon):
#     # This is a simplified version - in a real app you'd use reverse geocoding
#     if 24 <= lat <= 49 and -125 <= lon <= -66:
#         return "United States"
#     elif 35 <= lat <= 71 and -10 <= lon <= 40:
#         return "Europe"
#     elif -60 <= lat <= 15 and -90 <= lon <= -30:
#         return "South America"
#     elif -12 <= lat <= 38 and 25 <= lon <= 60:
#         return "Middle East"
#     elif -40 <= lat <= -10 and 110 <= lon <= 180:
#         return "Australia"
#     else:
#         return "Unknown"

# predictions['country'] = predictions.apply(lambda x: get_country(x['latitude'], x['longitude']), axis=1)

# # Sidebar filters
# st.sidebar.title("Filter Predictions")
# min_year, max_year = st.sidebar.slider(
#     "Year Range",
#     min_value=2025,
#     max_value=2030,
#     value=(2025, 2030)
# )

# min_magnitude = st.sidebar.slider(
#     "Minimum Magnitude",
#     min_value=5.0,
#     max_value=9.0,
#     value=5.0,
#     step=0.1
# )

# # Filter data
# filtered_data = predictions[
#     (predictions['year'] >= min_year) & 
#     (predictions['year'] <= max_year) &
#     (predictions['predicted_magnitude'] >= min_magnitude)
# ].copy()

# # Main content
# st.title("🌍 Upcoming Earthquake Locations (2025-2030)")
# st.markdown("""
# ### Predicted locations of significant earthquakes
# """)

# # Display predictions in two columns
# col1, col2 = st.columns(2)

# with col1:
#     st.header("Predicted Locations")
#     if not filtered_data.empty:
#         for idx, row in filtered_data.iterrows():
#             # Determine alert color based on magnitude
#             if row['predicted_magnitude'] >= 7.0:
#                 alert_color = "#ff0000"  # red
#             elif row['predicted_magnitude'] >= 6.0:
#                 alert_color = "#ff9900"  # orange
#             else:
#                 alert_color = "#ffcc00"  # yellow
            
#             st.markdown(f"""
#             <div class="alert-card" style="border-left: 5px solid {alert_color};">
#                 <h3 class="location-header">Predicted Earthquake</h3>
#                 <p><strong>Year:</strong> {int(row['year'])}</p>
#                 <p><strong>Predicted Magnitude:</strong> {row['predicted_magnitude']:.1f}</p>
#                 <p><strong>Location:</strong> {row['latitude']:.2f}°N, {row['longitude']:.2f}°E</p>
#                 <p><strong>Country/Region:</strong> {row['country']}</p>
#                 <p><strong>Depth:</strong> {row['depth']:.1f} km</p>
#             </div>
#             """, unsafe_allow_html=True)
#     else:
#         st.warning("No significant earthquakes predicted for the selected filters.")

# with col2:
#     st.header("World Map Visualization")
#     if not filtered_data.empty:
#         # Create a pydeck map
#         layer = pdk.Layer(
#             "ScatterplotLayer",
#             data=filtered_data,
#             get_position='[longitude, latitude]',
#             get_radius='predicted_magnitude * 20000',
#             get_fill_color='[255, predicted_magnitude * 25, 0, 160]',
#             pickable=True,
#             auto_highlight=True
#         )
        
#         view_state = pdk.ViewState(
#             latitude=filtered_data['latitude'].mean(),
#             longitude=filtered_data['longitude'].mean(),
#             zoom=1,
#             pitch=0
#         )
        
#         r = pdk.Deck(
#             layers=[layer],
#             initial_view_state=view_state,
#             tooltip={
#                 "html": "<b>Magnitude:</b> {predicted_magnitude}<br/>"
#                        "<b>Location:</b> {latitude:.2f}°N, {longitude:.2f}°E<br/>"
#                        "<b>Year:</b> {year}",
#                 "style": {
#                     "backgroundColor": "white",
#                     "color": "black"
#                 }
#             }
#         )
        
#         st.pydeck_chart(r)
#     else:
#         st.info("Adjust filters to see predicted earthquake locations.")

# # Data table
# st.header("Detailed Predictions")
# if not filtered_data.empty:
#     st.dataframe(filtered_data[['year', 'latitude', 'longitude', 'predicted_magnitude', 'depth', 'country']])
# else:
#     st.info("No data available for the selected filters.")

# # About section
# st.sidebar.header("About")
# st.sidebar.info("""
# This system predicts earthquake locations using:
# - Historical seismic data
# - Machine learning models
# - Geographical analysis
# """)




import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from PIL import Image
import pydeck as pdk

# Set page config
st.set_page_config(
    page_title="Earthquake Prediction System",
    page_icon="🌍",
    layout="wide"
)

# Custom CSS for styling
st.markdown("""
<style>
.alert-card {
    background-color:white;
    color: #212529; 
    padding: 1.5rem;
    margin-bottom: 1rem;
    border-radius: 0.5rem;
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    border-left: 5px solid #d9534f;
}
.location-header {
    color: #d9534f;
    margin-bottom: 0.5rem;
}
.map-container {
    border-radius: 0.5rem;
    overflow: hidden;
}
</style>
""", unsafe_allow_html=True)

# Load predictions
try:
    predictions = pd.read_csv('earthquake_predictions_2025-2030.csv')
except:
    # Sample fallback data
    data = {
        'year': [2025, 2026, 2027, 2028, 2029, 2030] * 3,
        'latitude': [36.77, 34.05, 38.58, 37.77, 35.47, 32.72] * 3,
        'longitude': [-119.42, -118.24, -121.49, -122.42, -120.67, -117.16] * 3,
        'depth': [10.5, 15.2, 8.7, 12.3, 9.8, 11.5] * 3,
        'predicted_magnitude': [5.2, 6.1, 5.7, 7.2, 6.5, 5.9] * 3
    }
    predictions = pd.DataFrame(data)

# Country assignment (simplified)
def get_country(lat, lon):
    if 24 <= lat <= 49 and -125 <= lon <= -66:
        return "United States"
    elif 35 <= lat <= 71 and -10 <= lon <= 40:
        return "Europe"
    elif -60 <= lat <= 15 and -90 <= lon <= -30:
        return "South America"
    elif -12 <= lat <= 38 and 25 <= lon <= 60:
        return "Middle East"
    elif -40 <= lat <= -10 and 110 <= lon <= 180:
        return "Australia"
    else:
        return "Unknown"

predictions['country'] = predictions.apply(lambda x: get_country(x['latitude'], x['longitude']), axis=1)

# Sidebar filters
st.sidebar.title("Filter Predictions")
min_year, max_year = st.sidebar.slider(
    "Year Range",
    min_value=2025,
    max_value=2030,
    value=(2025, 2030)
)

min_magnitude = st.sidebar.slider(
    "Minimum Magnitude",
    min_value=5.0,
    max_value=9.0,
    value=5.0,
    step=0.1
)

# Filter data, excluding 'Unknown' regions
filtered_data = predictions[
    (predictions['year'] >= min_year) & 
    (predictions['year'] <= max_year) &
    (predictions['predicted_magnitude'] >= min_magnitude) &
    (predictions['country'] != "Unknown")
].copy()

# Main content
st.title("🌍 Upcoming Earthquake Locations (2025–2030)")
st.markdown("### Predicted locations of significant earthquakes")

col1, col2 = st.columns(2)

with col1:
    st.header("Predicted Locations")
    if not filtered_data.empty:
        for idx, row in filtered_data.iterrows():
            if row['predicted_magnitude'] >= 7.0:
                alert_color = "#ff0000"
            elif row['predicted_magnitude'] >= 6.0:
                alert_color = "#ff9900"
            else:
                alert_color = "#ffcc00"
            
            st.markdown(f"""
            <div class="alert-card" style="border-left: 5px solid {alert_color};">
                <h3 class="location-header">Predicted Earthquake</h3>
                <p><strong>Year:</strong> {int(row['year'])}</p>
                <p><strong>Predicted Magnitude:</strong> {row['predicted_magnitude']:.1f}</p>
                <p><strong>Location:</strong> {row['latitude']:.2f}°N, {row['longitude']:.2f}°E</p>
                <p><strong>Country/Region:</strong> {row['country']}</p>
                <p><strong>Depth:</strong> {row['depth']:.1f} km</p>
            </div>
            """, unsafe_allow_html=True)
    else:
        st.warning("No significant earthquakes predicted for the selected filters.")

with col2:
    st.header("World Map Visualization")
    if not filtered_data.empty:
        layer = pdk.Layer(
            "ScatterplotLayer",
            data=filtered_data,
            get_position='[longitude, latitude]',
            get_radius='predicted_magnitude * 20000',
            get_fill_color='[255, predicted_magnitude * 25, 0, 160]',
            pickable=True,
            auto_highlight=True
        )
        
        view_state = pdk.ViewState(
            latitude=filtered_data['latitude'].mean(),
            longitude=filtered_data['longitude'].mean(),
            zoom=1,
            pitch=0
        )
        
        r = pdk.Deck(
            layers=[layer],
            initial_view_state=view_state,
            tooltip={
                "html": "<b>Magnitude:</b> {predicted_magnitude}<br/>"
                        "<b>Location:</b> {latitude:.2f}°N, {longitude:.2f}°E<br/>"
                        "<b>Year:</b> {year}",
                "style": {"backgroundColor": "white", "color": "black"}
            }
        )
        
        st.pydeck_chart(r)
    else:
        st.info("Adjust filters to see predicted earthquake locations.")

# Data table
st.header("Detailed Predictions")
if not filtered_data.empty:
    st.dataframe(filtered_data[['year', 'latitude', 'longitude', 'predicted_magnitude', 'depth', 'country']])
else:
    st.info("No data available for the selected filters.")

# About section
st.sidebar.header("About")
st.sidebar.info("""
This system predicts earthquake locations using:
- Historical seismic data  
- Machine learning models  
- Geographical analysis
""")
